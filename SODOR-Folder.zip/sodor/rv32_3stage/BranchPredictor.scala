package sodor.stage3

import chisel3._
import chisel3.util._

class BranchPredictor(entries: Int) extends Module {
  val io = IO(new Bundle {
    val pc = Input(UInt(32.W))
    val is_branch = Input(Bool())
    val actual_taken = Input(Bool())
    val update = Input(Bool())
    val prediction = Output(Bool())
    
    // Simplified diagnostic outputs
    val total_predictions = Output(UInt(32.W))
    val correct_predictions = Output(UInt(32.W))
  })

  // Larger BHT with more sophisticated indexing
  val bht = RegInit(VecInit(Seq.fill(entries)(2.U(2.W))))
  
  // Global history register for more context
  val global_history = RegInit(0.U(8.W))
  
  // More complex indexing combining PC and global history
  val index = ((io.pc >> 2.U) ^ global_history)(log2Ceil(entries) - 1, 0)
  
  // Prediction and tracking registers
  val total_predictions = RegInit(0.U(32.W))
  val correct_predictions = RegInit(0.U(32.W))
  
  // Prediction logic
  val prediction = Mux(io.is_branch, bht(index)(1), false.B)
  io.prediction := prediction
  
  // Tracking prediction stats
  when(io.is_branch) {
    total_predictions := total_predictions + 1.U
    when(prediction === io.actual_taken) {
      correct_predictions := correct_predictions + 1.U
    }
  }
  
  // Diagnostic outputs
  io.total_predictions := total_predictions
  io.correct_predictions := correct_predictions
  
  // Update branch history
  when(io.update && io.is_branch) {
    // Update global history
    global_history := Cat(global_history(6, 0), io.actual_taken)
    
    when(io.actual_taken) {
      bht(index) := Mux(bht(index) === 3.U, 3.U, bht(index) + 1.U)
    }.otherwise {
      bht(index) := Mux(bht(index) === 0.U, 0.U, bht(index) - 1.U)
    }
  }
}
