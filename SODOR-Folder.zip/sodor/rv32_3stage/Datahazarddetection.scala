package sodor.stage3

import chisel3._
import chisel3.util._

class Datahazarddetection extends Module {
  val io = IO(new Bundle {
    val id_rs1_addr = Input(UInt(5.W))
    val id_rs2_addr = Input(UInt(5.W))
    val ex_rd_addr = Input(UInt(5.W))
    val ex_mem_read = Input(Bool())
    
    val stall = Output(Bool())
    val pc_write = Output(Bool())
    val if_id_write = Output(Bool())
  })

  // Load-use hazard detection
  val load_use_hazard = io.ex_mem_read && 
    ((io.ex_rd_addr === io.id_rs1_addr) || 
     (io.ex_rd_addr === io.id_rs2_addr))

  io.stall := load_use_hazard
  io.pc_write := !load_use_hazard
  io.if_id_write := !load_use_hazard
}
