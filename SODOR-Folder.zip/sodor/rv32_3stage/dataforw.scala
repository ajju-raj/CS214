package sodor.stage3

import chisel3._
import chisel3.util._

class dataforw extends Module {
  val io = IO(new Bundle {
    val ex_rs1_addr = Input(UInt(5.W))
    val ex_rs2_addr = Input(UInt(5.W))
    val mem_rd_addr = Input(UInt(5.W))
    val wb_rd_addr = Input(UInt(5.W))
    val mem_reg_write = Input(Bool())
    val wb_reg_write = Input(Bool())
    
    val forward_a = Output(UInt(2.W))
    val forward_b = Output(UInt(2.W))
  })

  // Forwarding logic for rs1 (input to EX stage)
  io.forward_a := MuxCase(0.U, Seq(
    // Forward from MEM if the register is being written to in MEM
    (io.mem_reg_write && (io.mem_rd_addr =/= 0.U) && (io.mem_rd_addr === io.ex_rs1_addr)) -> 1.U,
    
    // Forward from WB if the register is being written to in WB and MEM is not forwarding
    (io.wb_reg_write && (io.wb_rd_addr =/= 0.U) && (io.wb_rd_addr === io.ex_rs1_addr) && 
     !(io.mem_reg_write && (io.mem_rd_addr =/= 0.U) && (io.mem_rd_addr === io.ex_rs1_addr))) -> 2.U
  ))

  // Forwarding logic for rs2 (input to EX stage)
  io.forward_b := MuxCase(0.U, Seq(
    // Forward from MEM if the register is being written to in MEM
    (io.mem_reg_write && (io.mem_rd_addr =/= 0.U) && (io.mem_rd_addr === io.ex_rs2_addr)) -> 1.U,
    
    // Forward from WB if the register is being written to in WB and MEM is not forwarding
    (io.wb_reg_write && (io.wb_rd_addr =/= 0.U) && (io.wb_rd_addr === io.ex_rs2_addr) && 
     !(io.mem_reg_write && (io.mem_rd_addr =/= 0.U) && (io.mem_rd_addr === io.ex_rs2_addr))) -> 2.U
  ))
}

