package sodor.stage3

import chisel3._
import chisel3.util._
import freechips.rocketchip.rocket.{CSR, Causes}
import sodor.common._
import sodor.common.Instructions._
import sodor.stage3.Constants._
import sodor.stage3.ALU._
import sodor.stage3.BranchPredictor
import sodor.stage3.dataforw
import sodor.stage3.Datahazarddetection

class CtrlSignals extends Bundle {
  val exe_kill        = Output(Bool())    // squash EX stage (exception/mret occurred)
  val pc_sel          = Output(UInt(3.W))
  val brjmp_sel       = Output(Bool())
  val op1_sel         = Output(UInt(2.W))
  val op2_sel         = Output(UInt(2.W))
  val alu_fun         = Output(UInt(SZ_ALU_FN.W))
  val wb_sel          = Output(UInt(2.W))
  val rf_wen          = Output(Bool())
  val bypassable      = Output(Bool())    // instruction's result can be bypassed
  val csr_cmd         = Output(UInt(CSR.SZ.W))
  val dmem_val        = Output(Bool())
  val dmem_fcn        = Output(UInt(M_X.getWidth.W))
  val dmem_typ        = Output(UInt(3.W))
  val exception       = Output(Bool())
  val exception_cause = Output(UInt(32.W))
}

class CpathIo(implicit val conf: SodorCoreParams) extends Bundle {
  val dcpath = Flipped(new DebugCPath())
  val imem   = Flipped(new FrontEndCpuIO())
  val dmem   = new MemPortIo(conf.xprlen)
  val dat    = Flipped(new DatToCtlIo())
  val ctl    = new CtrlSignals()
  //override def cloneType: this.type = new CpathIo().asInstanceOf[this.type]

}

class CtlPath(implicit val conf: SodorCoreParams) extends Module {
  val io = IO(new CpathIo())
  io := DontCare

  // PC Selection Constants
  val PC_4   = 0.U(3.W)
  val PC_BR  = 1.U(3.W)
  val PC_J   = 2.U(3.W)
  val PC_JR  = 3.U(3.W)
  val PC_EXC = 4.U(3.W)

  // Branch Predictor
  val branch_predictor = Module(new BranchPredictor(entries = 4096))

  // Hazard Detection and Data Forwarding Units
  val hazard_detection_unit = Module(new Datahazarddetection())
  val data_forwarding_unit  = Module(new dataforw())

  // Fetch stage branch detection
  val fetch_pc    = io.imem.resp.bits.pc
  val is_branch   = Wire(Bool())
  is_branch       := io.imem.resp.bits.inst(6, 0) === "b1100011".U  // B-type instruction opcode

  // Branch predictor connections
  branch_predictor.io.pc           := fetch_pc
  branch_predictor.io.is_branch    := is_branch
  branch_predictor.io.update       := false.B
  branch_predictor.io.actual_taken := false.B
  val prediction                   = branch_predictor.io.prediction

  // Decode stage control signals
  val csignals = ListLookup(io.imem.resp.bits.inst,
    // Default control signals
    List(N, BR_N, N, OP1_X, OP2_X, ALU_X, WB_X, REN_0, N, MEN_0, M_X, MT_X, CSR.N, M_N),
    Array(
      LW      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_MEM, REN_1, N, MEN_1, M_XRD, MT_W,  CSR.N, M_N),
      LB      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_MEM, REN_1, N, MEN_1, M_XRD, MT_B,  CSR.N, M_N),
      LBU     -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_MEM, REN_1, N, MEN_1, M_XRD, MT_BU, CSR.N, M_N),
      LH      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_MEM, REN_1, N, MEN_1, M_XRD, MT_H,  CSR.N, M_N),
      LHU     -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_MEM, REN_1, N, MEN_1, M_XRD, MT_HU, CSR.N, M_N),
      SW      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMS , ALU_ADD , WB_X  , REN_0, N, MEN_1, M_XWR, MT_W,  CSR.N, M_N),
      SB      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMS , ALU_ADD , WB_X  , REN_0, N, MEN_1, M_XWR, MT_B,  CSR.N, M_N),
      SH      -> List(Y, BR_N  , N, OP1_RS1, OP2_IMS , ALU_ADD , WB_X  , REN_0, N, MEN_1, M_XWR, MT_H,  CSR.N, M_N),

      AUIPC   -> List(Y, BR_N  , N, OP1_IMU, OP2_PC  , ALU_ADD  ,WB_ALU, REN_1, Y, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      LUI     -> List(Y, BR_N  , N, OP1_IMU, OP2_X   , ALU_COPY1,WB_ALU, REN_1, Y, MEN_0, M_X ,  MT_X,  CSR.N, M_N),

      ADDI    -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_ADD , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      ANDI    -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_AND , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      ORI     -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_OR  , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      XORI    -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_XOR , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SLTI    -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_SLT , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SLTIU   -> List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_SLTU, WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SLLI_RV32->List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_SLL , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SRAI_RV32->List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_SRA , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SRLI_RV32->List(Y, BR_N  , N, OP1_RS1, OP2_IMI , ALU_SRL , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),

      SLL     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_SLL , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      ADD     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_ADD , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SUB     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_SUB , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SLT     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_SLT , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      SLTU    -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_SLTU, WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      AND     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_AND , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      OR      -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_OR  , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),
      XOR     -> List(Y, BR_N  , N, OP1_RS1, OP2_RS2 , ALU_XOR , WB_ALU, REN_1, Y, MEN_0, M_X  , MT_X,  CSR.N, M_N),

      BEQ     -> List(N, BR_EQ , N, OP1_RS1, OP2_RS2 , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      BNE     -> List(N, BR_NE , N, OP1_RS1, OP2_RS2 , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      BGE     -> List(N, BR_GE , N, OP1_RS1, OP2_RS2 , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      BLT     -> List(N, BR_LT , N, OP1_RS1, OP2_RS2 , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      JAL     -> List(Y, BR_N  , N, OP1_X   , OP2_X   , ALU_X   , WB_PC4, REN_1, Y, MEN_0, M_X ,  MT_X,  CSR.N, M_N),
      JALR    -> List(Y, BR_JR , N, OP1_RS1, OP2_X   , ALU_ADD , WB_PC4, REN_1, Y, MEN_0, M_X ,  MT_X,  CSR.N, M_N),

      ECALL   -> List(N, BR_N  , N, OP1_X   , OP2_X   , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.W, M_N),
      MRET    -> List(N, BR_N  , N, OP1_X   , OP2_X   , ALU_X   , WB_X , REN_0, N, MEN_0, M_X ,  MT_X,  CSR.W, M_N)
    )
  )

  // Set control signals based on instruction decoding
  io.ctl.exe_kill := false.B
  io.ctl.pc_sel := PC_4
  io.ctl.brjmp_sel := prediction // Use prediction from the branch predictor
  io.ctl.alu_fun := csignals(5)
  io.ctl.wb_sel := csignals(6)
  io.ctl.rf_wen := csignals(7)
  io.ctl.bypassable := csignals(8)
  io.ctl.csr_cmd := csignals(12)
  io.ctl.dmem_val := csignals(9)
  io.ctl.dmem_fcn := csignals(10)
  io.ctl.dmem_typ := csignals(11)

  // Handle exception
  io.ctl.exception := false.B
  io.ctl.exception_cause := 0.U  // Default to no exception (0 for no exception)
}

